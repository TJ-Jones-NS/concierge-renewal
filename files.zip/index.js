import { useState } from 'react';
import Head from 'next/head';

export default function Home() {
  const [homeowner, setHomeowner] = useState('');
  const [previewData, setPreviewData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [suggestions, setSuggestions] = useState([]);

  const searchHomeowners = async (query) => {
    if (!query.trim()) {
      setSuggestions([]);
      return;
    }

    try {
      const res = await fetch(`/api/homeowners?search=${encodeURIComponent(query)}`);
      const data = await res.json();
      setSuggestions(data.homeowners || []);
    } catch (err) {
      console.error('Search error:', err);
    }
  };

  const loadPreview = async () => {
    if (!homeowner.trim()) {
      setError('Please enter a homeowner name');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const res = await fetch(`/api/preview?homeowner=${encodeURIComponent(homeowner)}`);
      
      if (!res.ok) {
        throw new Error('Homeowner not found');
      }

      const data = await res.json();
      setPreviewData(data);
    } catch (err) {
      setError(err.message);
      setPreviewData(null);
    } finally {
      setLoading(false);
    }
  };

  const downloadRenewal = async () => {
    try {
      const res = await fetch(`/api/generate?homeowner=${encodeURIComponent(homeowner)}`);
      
      if (!res.ok) {
        throw new Error('Failed to generate document');
      }

      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${homeowner}_Renewal_${new Date().toISOString().split('T')[0]}.docx`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
    } catch (err) {
      setError('Failed to download document: ' + err.message);
    }
  };

  return (
    <>
      <Head>
        <title>Home Concierge Renewal Generator</title>
        <meta name="description" content="Generate renewal documents for Home Concierge clients" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
      </Head>

      <div className="container">
        <div className="header">
          <h1>🏡 Home Concierge Renewal Generator</h1>
          <p>Search for a homeowner and generate their renewal document</p>
        </div>

        <div className="search-box">
          <h2>Select Homeowner</h2>
          <div className="search-input-group">
            <input
              type="text"
              value={homeowner}
              onChange={(e) => {
                setHomeowner(e.target.value);
                searchHomeowners(e.target.value);
              }}
              onKeyPress={(e) => e.key === 'Enter' && loadPreview()}
              placeholder="Type homeowner name..."
              autoComplete="off"
            />
            <button onClick={loadPreview} disabled={loading}>
              {loading ? 'Loading...' : 'Preview'}
            </button>
          </div>

          {suggestions.length > 0 && (
            <div className="suggestions">
              {suggestions.map((name, idx) => (
                <div
                  key={idx}
                  className="suggestion-item"
                  onClick={() => {
                    setHomeowner(name);
                    setSuggestions([]);
                  }}
                >
                  {name}
                </div>
              ))}
            </div>
          )}
        </div>

        {error && (
          <div className="error">{error}</div>
        )}

        {previewData && (
          <div className="preview-box">
            <div className="preview-header">
              <h2>{previewData.homeowner}</h2>
              <button className="btn-success" onClick={downloadRenewal}>
                📥 Download Word Document
              </button>
            </div>

            <div className="metrics">
              <div className="metric-card">
                <div className="label">Total Jobs</div>
                <div className="value">{previewData.metrics.total_jobs}</div>
              </div>
              <div className="metric-card">
                <div className="label">Hours Saved</div>
                <div className="value">{previewData.metrics.time_savings}</div>
              </div>
              <div className="metric-card">
                <div className="label">Cost Savings</div>
                <div className="value">${previewData.metrics.cost_savings.toFixed(2)}</div>
              </div>
            </div>

            <div className="jobs-section">
              <h3>✅ DONE</h3>
              <ul className="job-list">
                {previewData.done.length > 0 ? (
                  previewData.done.map((job, idx) => (
                    <li key={idx} className="job-item done">
                      <strong>{job.project}</strong>
                      <div className="details">
                        Pro: {job.pro} | Amount: ${job.amount.toFixed(2)}
                      </div>
                    </li>
                  ))
                ) : (
                  <li className="empty-state">No completed jobs</li>
                )}
              </ul>
            </div>

            <div className="jobs-section">
              <h3>⏳ Outstanding</h3>
              <ul className="job-list">
                {previewData.outstanding.length > 0 ? (
                  previewData.outstanding.map((job, idx) => (
                    <li key={idx} className="job-item outstanding">
                      <strong>{job.project}</strong>
                      <div className="details">Status: {job.status}</div>
                    </li>
                  ))
                ) : (
                  <li className="empty-state">No outstanding jobs</li>
                )}
              </ul>
            </div>

            <div className="jobs-section">
              <h3>📋 UPCOMING</h3>
              <ul className="job-list">
                {previewData.upcoming.length > 0 ? (
                  previewData.upcoming.map((job, idx) => (
                    <li key={idx} className="job-item upcoming">
                      <strong>{job.project}</strong>
                    </li>
                  ))
                ) : (
                  <li className="empty-state">No upcoming jobs</li>
                )}
              </ul>
            </div>
          </div>
        )}
      </div>

      <style jsx>{`
        * {
          margin: 0;
          padding: 0;
          box-sizing: border-box;
        }

        .container {
          min-height: 100vh;
          padding: 20px;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, sans-serif;
        }

        .header {
          text-align: center;
          color: white;
          margin-bottom: 40px;
        }

        .header h1 {
          font-size: 2.5em;
          margin-bottom: 10px;
        }

        .header p {
          font-size: 1.1em;
          opacity: 0.9;
        }

        .search-box {
          background: white;
          border-radius: 12px;
          padding: 30px;
          box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
          margin-bottom: 30px;
          max-width: 1200px;
          margin-left: auto;
          margin-right: auto;
        }

        .search-box h2 {
          margin-bottom: 20px;
          color: #333;
        }

        .search-input-group {
          display: flex;
          gap: 10px;
          margin-bottom: 15px;
        }

        input {
          flex: 1;
          padding: 15px;
          font-size: 16px;
          border: 2px solid #ddd;
          border-radius: 8px;
          transition: border-color 0.3s;
        }

        input:focus {
          outline: none;
          border-color: #667eea;
        }

        button {
          padding: 15px 30px;
          font-size: 16px;
          border: none;
          border-radius: 8px;
          cursor: pointer;
          transition: all 0.3s;
          font-weight: 600;
          background: #667eea;
          color: white;
        }

        button:hover {
          background: #5568d3;
          transform: translateY(-2px);
          box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }

        button:disabled {
          background: #ccc;
          cursor: not-allowed;
          transform: none;
        }

        .btn-success {
          background: #10b981;
        }

        .btn-success:hover {
          background: #059669;
        }

        .suggestions {
          background: white;
          border: 1px solid #ddd;
          border-radius: 8px;
          max-height: 200px;
          overflow-y: auto;
        }

        .suggestion-item {
          padding: 12px 15px;
          cursor: pointer;
          transition: background 0.2s;
          border-bottom: 1px solid #f0f0f0;
        }

        .suggestion-item:last-child {
          border-bottom: none;
        }

        .suggestion-item:hover {
          background: #f5f5f5;
        }

        .error {
          background: #fee;
          color: #c33;
          padding: 15px;
          border-radius: 8px;
          margin-bottom: 20px;
          max-width: 1200px;
          margin-left: auto;
          margin-right: auto;
        }

        .preview-box {
          background: white;
          border-radius: 12px;
          padding: 30px;
          box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
          max-width: 1200px;
          margin-left: auto;
          margin-right: auto;
        }

        .preview-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 30px;
          padding-bottom: 20px;
          border-bottom: 3px solid #667eea;
        }

        .preview-header h2 {
          color: #333;
          font-size: 1.8em;
        }

        .metrics {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
          gap: 20px;
          margin-bottom: 30px;
        }

        .metric-card {
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          color: white;
          padding: 20px;
          border-radius: 10px;
          text-align: center;
        }

        .metric-card .label {
          font-size: 0.9em;
          opacity: 0.9;
          margin-bottom: 8px;
        }

        .metric-card .value {
          font-size: 2em;
          font-weight: bold;
        }

        .jobs-section {
          margin-bottom: 30px;
        }

        .jobs-section h3 {
          color: #333;
          margin-bottom: 15px;
          font-size: 1.3em;
          padding: 10px;
          background: #f8f9fa;
          border-radius: 6px;
        }

        .job-list {
          list-style: none;
          padding-left: 0;
        }

        .job-item {
          padding: 12px;
          background: #f8f9fa;
          margin-bottom: 8px;
          border-radius: 6px;
          border-left: 4px solid #667eea;
        }

        .job-item.done {
          border-left-color: #10b981;
        }

        .job-item.outstanding {
          border-left-color: #f59e0b;
        }

        .job-item.upcoming {
          border-left-color: #3b82f6;
        }

        .job-item strong {
          color: #333;
        }

        .job-item .details {
          color: #666;
          font-size: 0.9em;
          margin-top: 5px;
        }

        .empty-state {
          text-align: center;
          padding: 20px;
          color: #999;
          font-style: italic;
        }
      `}</style>
    </>
  );
}
