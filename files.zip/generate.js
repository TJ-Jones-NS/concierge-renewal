const { Document, Packer, Paragraph, TextRun, AlignmentType, HeadingLevel } = require('docx');
const { getSheetData, categorizeJobs, calculateMetrics } = require('../../lib/sheets');

export default async function handler(req, res) {
  try {
    const { homeowner } = req.query;

    if (!homeowner) {
      return res.status(400).json({ error: 'Homeowner name required' });
    }

    const data = await getSheetData();
    const homeownerJobs = data.filter(
      row => row.Homeowner && row.Homeowner.trim() === homeowner.trim()
    );

    if (homeownerJobs.length === 0) {
      return res.status(404).json({ error: 'Homeowner not found' });
    }

    const { done, outstanding, upcoming } = categorizeJobs(homeownerJobs);
    const metrics = calculateMetrics(homeownerJobs, done);

    // Create Word document
    const doc = new Document({
      sections: [{
        properties: {},
        children: [
          // Title
          new Paragraph({
            text: `Home Concierge Summary - ${homeowner}`,
            heading: HeadingLevel.HEADING_1,
            alignment: AlignmentType.CENTER,
            spacing: { after: 200 },
          }),

          // Introduction
          new Paragraph({
            text: 'The Home Concierge summary is constructed to give an overview of projects completed, hours saved, and cost savings by using vetted, local contractors.',
            spacing: { after: 200 },
          }),

          new Paragraph({
            text: 'As part of our Home Concierge service, we actively manage your Home Hub.',
            spacing: { after: 400 },
          }),

          // Divider
          new Paragraph({
            text: '────────────────────────────────────────────────────────────────────',
            spacing: { after: 200 },
          }),

          // Projects Assisted
          new Paragraph({
            text: 'Projects Assisted',
            heading: HeadingLevel.HEADING_2,
            spacing: { before: 200, after: 200 },
          }),

          new Paragraph({
            children: [new TextRun({ text: 'DONE', bold: true })],
            spacing: { before: 200, after: 100 },
          }),

          ...done.map(job => {
            const amount = parseFloat(job['Amount Completed']) || 0;
            const pro = job['Pro Assigned'] || 'N/A';
            return new Paragraph({
              text: `• ${job.Project || 'Unnamed Project'} (Pro: ${pro}, Amount: $${amount.toFixed(2)})`,
              spacing: { after: 100 },
              bullet: { level: 0 },
            });
          }),

          ...(done.length === 0 ? [new Paragraph({ text: '• None', bullet: { level: 0 } })] : []),

          new Paragraph({
            children: [new TextRun({ text: 'Outstanding', bold: true })],
            spacing: { before: 200, after: 100 },
          }),

          ...outstanding.map(job => 
            new Paragraph({
              text: `• ${job.Project || 'Unnamed Project'} (Status: ${job.Status})`,
              spacing: { after: 100 },
              bullet: { level: 0 },
            })
          ),

          ...(outstanding.length === 0 ? [new Paragraph({ text: '• None', bullet: { level: 0 } })] : []),

          new Paragraph({
            children: [new TextRun({ text: 'UPCOMING', bold: true })],
            spacing: { before: 200, after: 100 },
          }),

          ...upcoming.map(job => 
            new Paragraph({
              text: `• ${job.Project || 'Unnamed Project'}`,
              spacing: { after: 100 },
              bullet: { level: 0 },
            })
          ),

          ...(upcoming.length === 0 ? [new Paragraph({ text: '• None', bullet: { level: 0 } })] : []),

          // Divider
          new Paragraph({
            text: '────────────────────────────────────────────────────────────────────',
            spacing: { before: 200, after: 200 },
          }),

          // Time Savings
          new Paragraph({
            text: 'Estimated Time Savings',
            heading: HeadingLevel.HEADING_2,
            spacing: { before: 200, after: 100 },
          }),

          new Paragraph({
            text: '*Assumes, conservatively, two hours saved per job.',
            spacing: { after: 200 },
          }),

          new Paragraph({
            text: `• Home Visit & Hub Organization: ~6 hours`,
            spacing: { after: 100 },
            bullet: { level: 0 },
          }),

          new Paragraph({
            text: `• Project Management: ${metrics.total_jobs} total jobs = ${metrics.total_jobs * 2} hours`,
            spacing: { after: 100 },
            bullet: { level: 0 },
          }),

          new Paragraph({
            children: [
              new TextRun({ text: `Total: ~${metrics.time_savings} hours saved`, bold: true })
            ],
            spacing: { before: 100, after: 200 },
          }),

          // Divider
          new Paragraph({
            text: '────────────────────────────────────────────────────────────────────',
            spacing: { before: 200, after: 200 },
          }),

          // Cost Savings
          new Paragraph({
            text: 'Estimated Cost Savings',
            heading: HeadingLevel.HEADING_2,
            spacing: { before: 200, after: 200 },
          }),

          new Paragraph({
            text: `~ $100/project × ${done.length} completed = $${metrics.cost_savings.toFixed(2)}+ saved through vetted contractors, offers, and fair pricing`,
            spacing: { after: 200 },
          }),

          // Divider
          new Paragraph({
            text: '────────────────────────────────────────────────────────────────────',
            spacing: { before: 200, after: 200 },
          }),

          // Home Hub
          new Paragraph({
            text: 'Home Hub',
            heading: HeadingLevel.HEADING_2,
            spacing: { before: 200, after: 200 },
          }),

          new Paragraph({
            text: 'All records, quotes, and contractor details are available in the Home Hub. Please note that the Home Hub will be deactivated if services are stopped.',
          }),
        ],
      }],
    });

    // Generate buffer
    const buffer = await Packer.toBuffer(doc);

    // Set response headers
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document');
    res.setHeader('Content-Disposition', `attachment; filename="${homeowner}_Renewal_${new Date().toISOString().split('T')[0]}.docx"`);
    res.send(buffer);

  } catch (error) {
    console.error('Error in generate API:', error);
    res.status(500).json({ error: 'Failed to generate document' });
  }
}
